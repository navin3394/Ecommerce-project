package com.niit.ShoppingCartBackEndProject;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCartDAO.CategoryDAO;
import com.niit.ShoppingCartModel.Category;

public class CategoryTest {
	public static void main(String[] args){
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
	    context.refresh();
	
CategoryDAO categoryDAO=(CategoryDAO)context.getBean("categoryDAO"); 
	    Category category=(Category)context.getBean("category"); 
	    category.setId("501");
	    category.setName("dsdfgh");
	    category.setDesc("connect people");
if ( categoryDAO.save(category)==true){
		System.out.println("Created Category Successfully");
}
else{
System.out.println("not able to create Category successfully");
}
	}
} 
