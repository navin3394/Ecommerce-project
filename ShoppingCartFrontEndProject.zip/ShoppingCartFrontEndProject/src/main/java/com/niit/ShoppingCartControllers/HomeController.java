package com.niit.ShoppingCartControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ShoppingCartDAO.CategoryDAO;
import com.niit.ShoppingCartModel.Category;

@Controller
public class HomeController {

/*@RequestMapping("/")	
public String home(){
	
	return "Home";
}}*/
	@Autowired
	CategoryDAO categoryDAO;
@RequestMapping("/")
public ModelAndView home() {
	ModelAndView mv=new ModelAndView ("Login");
	mv.addObject("message","Welcome u all");
	List<Category> categoryList=categoryDAO.list();
mv.addObject("categoryList",categoryList);
System.out.println("size:"+categoryList.size());
return mv;

}
/*@RequestMapping("/Register")
	public ModelAndView register()
	{
		ModelAndView mv=new ModelAndView("Registration");
		return mv;
	}
@RequestMapping("/Login")
public ModelAndView Login()
{
	ModelAndView mv=new ModelAndView("Registration");
	return mv;
}

*/
}