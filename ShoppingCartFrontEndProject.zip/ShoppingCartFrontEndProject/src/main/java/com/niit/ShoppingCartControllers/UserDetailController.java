package com.niit.ShoppingCartControllers;

import org.springframework.stereotype.Controller;

@Controller
public class UserDetailController {

}
