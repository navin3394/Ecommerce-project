package com.niit.ShoppingCartControllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ShoppingCartDAO.SupplierDAO;
import com.niit.ShoppingCartModel.Supplier;

@Controller
public class SupplierController {
	private static Logger Log=LoggerFactory.getLogger(SupplierController.class);
	
	@Autowired
	private SupplierDAO supplierDAO;
	@Autowired
	private Supplier supplier;
	
	@RequestMapping(value="/suppliers",method=RequestMethod.GET)
	public String listSuppliers(Model model){
		Log.debug("Starting of the method listSuppliers");
		model.addAttribute("supplier",supplier);
		model.addAttribute("supplierlist",supplierDAO.list());
		Log.debug("end of the method listSuppliers");
		return "supplier";
	}
	@RequestMapping(value="/suppliers/add",method=RequestMethod.GET)
	public String addSuppliers(@ModelAttribute("supplier")Supplier supplier){
		Log.debug("Starting of the method listSuppliers");
		ModelAndView mv=new ModelAndView();
		if(supplierDAO.get(supplier.getId())==null)
		{
			supplierDAO.save(supplier);
		}
			else{
			mv.addObject("error message","the record exist with this id"+supplier.getId());
			}
	//	supplierDAO.saveOrupdate(supplier);
		Log.debug("end of the method listSuppliers");
		return "supplier";
	}
	@RequestMapping(value="/supplier/remove{id}" )
	public ModelAndView deleteSupplier(@PathVariable("id") Supplier id)throws Exception {
		boolean flag=supplierDAO.delete(id);
		ModelAndView mv=new ModelAndView("supplier");
		String msg="Successfully done the operation";
		if(flag!=true)
		{
			msg="the operation could not be success";
		}
		mv.addObject("msg",msg);
		
		return mv;
	}
	@RequestMapping(value="/supplier/edit{id}")
	public void editCategory(@PathVariable("id") String id, Model model){
		if(supplierDAO.get(id)!=null){
			supplierDAO.update(supplier);
			model.addAttribute("mssg","Successfully updated");
		}
		else{
			model.addAttribute("error msg","couldnot update the record");
		}
		}}
