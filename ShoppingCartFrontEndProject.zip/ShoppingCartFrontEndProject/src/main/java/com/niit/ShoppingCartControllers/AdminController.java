package com.niit.ShoppingCartControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ShoppingCartDAO.CategoryDAO;
import com.niit.ShoppingCartDAO.ProductDAO;
import com.niit.ShoppingCartDAO.SupplierDAO;
import com.niit.ShoppingCartModel.Category;
import com.niit.ShoppingCartModel.Product;
import com.niit.ShoppingCartModel.Supplier;

public class AdminController {
	
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Category category;
	@Autowired 
	private SupplierDAO supplierDAO;
	@Autowired
	private Supplier supplier;
	@Autowired 
	private ProductDAO productDAO;
	@Autowired 
	private Product product;
	
	@RequestMapping(value="/manageCategories",method=RequestMethod.GET)
	public ModelAndView Categories(){
		ModelAndView mv=new ModelAndView("/home");
		mv.addObject("category", category);
		mv.addObject("isAdminClickedCategories", "true");
		mv.addObject("categorylist", categoryDAO.list());
		return mv;
		
	}
   @RequestMapping(value="/manageSuppliers",method=RequestMethod.GET)
   public ModelAndView Suppliers(){
	   ModelAndView mv=new ModelAndView("/home");
	   mv.addObject("supplier",supplier);
	   mv.addObject("isAdminClickedSupplier","true");
	   mv.addObject("supplierlist", supplierDAO.list());
	   return mv;
   }
   @RequestMapping(value="/mnageProducts",method=RequestMethod.GET)
   public ModelAndView Products(){
	   ModelAndView mv=new ModelAndView("/home");
	   mv.addObject("product",product);
	   mv.addObject("isAdminClickedSupplier","true");
	   mv.addObject("productlist", productDAO.list());
	   return mv;
   }
}
