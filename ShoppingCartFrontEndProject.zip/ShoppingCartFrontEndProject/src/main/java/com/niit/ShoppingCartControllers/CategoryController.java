package com.niit.ShoppingCartControllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ShoppingCartDAO.CategoryDAO;
import com.niit.ShoppingCartModel.Category;

@Controller
public class CategoryController {
	private static Logger log=LoggerFactory.getLogger(CategoryController.class);

	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired 
	private Category category;
	
	@RequestMapping(value="/categories", method=RequestMethod.GET)
	public String listCategories(Model model){
		log.debug("Starting of a method listCategories");
		model.addAttribute("category",category);
		model.addAttribute("categoryList",categoryDAO.list());
		log.debug("End of a method listCategories");
		return "category";
	}
	@RequestMapping(value="/category/add",method=RequestMethod.GET)
	public String addCategories(@ModelAttribute("category") Category category){
		log.debug("Starting of a Method addCategory");
		
		ModelAndView mv=new ModelAndView();
		if(categoryDAO.get(category.getId())==null)
		{
			categoryDAO.save(category);
		}
			else{
			mv.addObject("error message","the record exist with this id"+category.getId());
			}
	//	categoryDAO.saveOrupdate(category);
	log.debug("End of a method addCategory");
		return "category";
	}
	@RequestMapping(value="/category/remove{id}" )
	public ModelAndView deleteCategory(@PathVariable("id") Category id)throws Exception {
		boolean flag=categoryDAO.delete(id);
		ModelAndView mv=new ModelAndView("category");
		String msg="Successfully done the operation";
		if(flag!=true)
		{
			msg="the operation could not be success";
		}
		mv.addObject("msg",msg);
		
		return mv;
	}
	@RequestMapping(value="/category/edit{id}")
	public void editCategory(@PathVariable("id") String id, Model model){
		if(categoryDAO.get(id)!=null){
			categoryDAO.update(category);
			model.addAttribute("mssg","Successfully updated");
		}
		else{
			model.addAttribute("error msg","couldnot update the record");
		}
		}
	}

